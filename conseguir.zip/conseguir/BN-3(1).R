install.packages("gRain")
install.packages("gRbase")
source("http://bioconductor.org/biocLite.R")
biocLite(c("graph", "RBGL", "Rgraphviz"))
library(gRbase)
library(gRain)

yn <- c("yes", "no")
a <- cptable(~ asia, values = c(1, 99), levels = yn)
t.a <- cptable(~ tub + asia, values = c(5, 95, 1, 99), levels = yn)
s <- cptable(~ smoke, values = c(5,5), levels = yn)
l.s <- cptable(~ lung + smoke, values = c(1, 9, 1, 99), levels = yn)
b.s <- cptable(~ bronc + smoke, values = c(6, 4, 3, 7), levels = yn)
x.e <- cptable(~ xray + either, values = c(98, 2, 5, 95), levels = yn)
d.be <- cptable(~ dysp + bronc + either, values = c(9, 1, 7, 3, 8, 2, 1, 9), levels = yn)
e.lt <- ortable(~ either + lung + tub, levels = yn)

bn.gin <- grain(compileCPT(list(a, t.a, s, l.s, b.s, e.lt, x.e, d.be)))
plot(bn.gin)

sim.gin <- simulate(bn.gin, nsim=5000)
head(sim.gin, n=10)

# say we want to know P(Lung,Bronc):
xtabs(~ lung+bronc, data=sim.gin) / nrow(sim.gin)

# we can also compute the true P(Lung,Bronc) from the bayes net, since we know their true CPTs:
querygrain(bn.gin, nodes = c("lung", "bronc"), type = "joint")

new.observation <- data.frame(dysp = "yes",
                              either = "yes",
                              tub="no",
                              asia="no",
                              xray="yes",
                              smoke="yes")

predict(bn.gin, 
        newdata = new.observation,
        predictors=c("smoke", "asia", "tub" , "dysp", "xray"), 
        response = c("lung", "bronc"),
        type = "dist")

